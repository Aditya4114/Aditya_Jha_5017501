package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Customer;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();

    @PostMapping("/register")
    public Customer registerCustomer(@RequestBody Customer customer) {
        customer.setId((long) (customers.size() + 1)); // Simple ID generation logic
        customers.add(customer);
        return customer; // Returns the newly created customer
    }
    @PostMapping("/register/form")
    public Customer registerCustomerWithForm(
            @RequestParam("name") String name,
            @RequestParam("email") String email,
            @RequestParam("password") String password) {

        Customer customer = new Customer();
        customer.setId((long) (customers.size() + 1)); // Simple ID generation logic
        customer.setName(name);
        customer.setEmail(email);
        customer.setPassword(password);

        customers.add(customer);
        return customer; // Returns the newly created customer
    }

}
