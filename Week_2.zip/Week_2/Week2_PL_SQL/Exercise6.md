Exercise 6: Cursors

Scenario 1: Generate monthly statements for all customers.

o	Question: Write a PL/SQL block using an explicit cursor GenerateMonthlyStatements that retrieves all transactions for the current month and prints a statement for each customer.


DECLARE
  CURSOR cur_transactions IS
    SELECT t.AccountID, t.TransactionDate, t.Amount, c.Name AS CustomerName
    FROM Transactions t
    JOIN Accounts a ON t.AccountID = a.AccountID
    JOIN Customers c ON a.CustomerID = c.CustomerID
    WHERE TRUNC(t.TransactionDate, 'MM') = TRUNC(SYSDATE, 'MM')
    ORDER BY c.Name, t.TransactionDate;

  v_account_id Accounts.AccountID%TYPE;
  v_transaction_date Transactions.TransactionDate%TYPE;
  v_amount Transactions.Amount%TYPE;
  v_customer_name Customers.Name%TYPE;

  v_current_customer_name VARCHAR2(50) := NULL;
  v_total_amount NUMBER := 0;

BEGIN
  OPEN cur_transactions;

  FETCH cur_transactions INTO v_account_id, v_transaction_date, v_amount, v_customer_name;


  WHILE cur_transactions%FOUND LOOP
    -- Check if we're dealing with a new customer
    IF v_customer_name != v_current_customer_name THEN
      -- Print the total amount for the previous customer
      IF v_current_customer_name IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Total: ' || v_total_amount);
        DBMS_OUTPUT.PUT_LINE('');
      END IF;
      v_current_customer_name := v_customer_name;
      DBMS_OUTPUT.PUT_LINE('Statement for ' || v_current_customer_name || ':');
      v_total_amount := 0;
    END IF;
    v_total_amount := v_total_amount + v_amount;
    FETCH cur_transactions INTO v_account_id, v_transaction_date, v_amount, v_customer_name;
  END LOOP;

  -- Print the total amount for the last customer
  DBMS_OUTPUT.PUT_LINE('Total: ' || v_total_amount);

  CLOSE cur_transactions;

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END;



---------------------------------------------------------------------------------------------------------------------------------



Scenario 2: Apply annual fee to all accounts.

o	Question: Write a PL/SQL block using an explicit cursor ApplyAnnualFee that deducts an annual maintenance fee from the balance of all accounts.


DECLARE

  CURSOR cur_accounts IS
    SELECT AccountID, Balance
    FROM Accounts;


  v_account_record cur_accounts%ROWTYPE;


  v_annual_fee NUMBER := 25;  -- assume the annual fee is $25

BEGIN

  OPEN cur_accounts;


  LOOP
    FETCH cur_accounts INTO v_account_record;
    EXIT WHEN cur_accounts%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('AccountID: ' || v_account_record.AccountID || ' Balance: ' || v_account_record.Balance)
    IF v_account_record.Balance >= v_annual_fee THEN
      -- Update the account balance to deduct the annual fee
      UPDATE Accounts
      SET Balance = Balance - v_annual_fee
      WHERE AccountID = v_account_record.AccountID;
      DBMS_OUTPUT.PUT_LINE('Annual fee of $' || v_annual_fee || ' deducted from account ' || v_account_record.AccountID);
    ELSE
      -- Print a message indicating the account balance is insufficient
      DBMS_OUTPUT.PUT_LINE('Insufficient balance in account ' || v_account_record.AccountID || ' to deduct annual fee');
    END IF;
  END LOOP;

  COMMIT;
  CLOSE cur_accounts;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('An error occurred: ' || SQLERRM);
END;



---------------------------------------------------------------------------------------------------------------------------------



Scenario 3: Update the interest rate for all loans based on a new policy.

o	Question: Write a PL/SQL block using an explicit cursor UpdateLoanInterestRates that fetches all loans and updates their interest rates based on the new policy.




DECLARE
  CURSOR cur_loans IS
    SELECT LoanID, InterestRate
    FROM Loans;

  v_loan_id NUMBER;
  v_current_interest_rate NUMBER;


  v_new_interest_rate NUMBER := 0.06;  -- Assume the new interest rate is 6%

BEGIN
  OPEN cur_loans;
  LOOP
    FETCH cur_loans INTO v_loan_id, v_current_interest_rate;
    EXIT WHEN cur_loans%NOTFOUND;
    UPDATE Loans
    SET InterestRate = v_new_interest_rate
    WHERE LoanID = v_loan_id;
    DBMS_OUTPUT.PUT_LINE('Interest rate for loan ' || v_loan_id || ' updated to ' || v_new_interest_rate);
  END LOOP;

  CLOSE cur_loans;


  COMMIT;

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Error updating interest rates: ' || SQLERRM);
END;







