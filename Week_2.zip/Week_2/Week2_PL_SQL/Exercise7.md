Exercise 7: Packages

Scenario 1: Group all customer-related procedures and functions into a package.

o	Question: Create a package CustomerManagement with procedures for adding a new customer, updating customer details, and a function to get customer balance.


CREATE OR REPLACE PACKAGE CustomerManagement AS
  PROCEDURE AddNewCustomer(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_Name IN Customers.Name%TYPE,
    p_DOB IN Customers.DOB%TYPE,
    p_Balance IN Customers.Balance%TYPE
  );

  PROCEDURE UpdateCustomerDetails(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_Name IN Customers.Name%TYPE,
    p_DOB IN Customers.DOB%TYPE,
    p_Balance IN Customers.Balance%TYPE
  );

  FUNCTION GetCustomerBalance(
    p_CustomerID IN Customers.CustomerID%TYPE
  ) RETURN NUMBER;
END CustomerManagement;


CREATE OR REPLACE PACKAGE BODY CustomerManagement AS
  PROCEDURE AddNewCustomer(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_Name IN Customers.Name%TYPE,
    p_DOB IN Customers.DOB%TYPE,
    p_Balance IN Customers.Balance%TYPE
  ) AS
  BEGIN
    BEGIN
      INSERT INTO Customers (CustomerID, Name, DOB, Balance)
      VALUES (p_CustomerID, p_Name, p_DOB, p_Balance);
      COMMIT;
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('CustomerID already exists.');
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error adding new customer: ' || SQLERRM);
    END;
  END AddNewCustomer;

  PROCEDURE UpdateCustomerDetails(
    p_CustomerID IN Customers.CustomerID%TYPE,
    p_Name IN Customers.Name%TYPE,
    p_DOB IN Customers.DOB%TYPE,
    p_Balance IN Customers.Balance%TYPE
  ) AS
  BEGIN
    BEGIN
      UPDATE Customers
      SET Name = p_Name, DOB = p_DOB, Balance = p_Balance
      WHERE CustomerID = p_CustomerID;
      IF SQL%ROWCOUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('CustomerID does not exist.');
      ELSE
        COMMIT;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error updating customer details: ' || SQLERRM);
    END;
  END UpdateCustomerDetails;

  FUNCTION GetCustomerBalance(
    p_CustomerID IN Customers.CustomerID%TYPE
  ) RETURN NUMBER AS
    v_Balance NUMBER := 0;  -- Initialize to 0
  BEGIN
    BEGIN
      SELECT NVL(Balance, 0)  -- Handle NULL values
      INTO v_Balance
      FROM Customers
      WHERE CustomerID = p_CustomerID;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_Balance := 0;  -- No customer found
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error retrieving customer balance: ' || SQLERRM);
    END;
    RETURN v_Balance;
  END GetCustomerBalance;
END CustomerManagement;



---------------------------------------------------------------------------------------------------------------------------------



Scenario 2: Create a package to manage employee data.

o	Question: Write a package EmployeeManagement with procedures to hire new employees, update employee details, and a function to calculate annual salary.



CREATE OR REPLACE PACKAGE EmployeeManagement AS
  PROCEDURE HireEmployee(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_Name IN Employees.Name%TYPE,
    p_Position IN Employees.Position%TYPE,
    p_Salary IN Employees.Salary%TYPE,
    p_Department IN Employees.Department%TYPE,
    p_HireDate IN Employees.HireDate%TYPE
  );

  PROCEDURE UpdateEmployeeDetails(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_Name IN Employees.Name%TYPE,
    p_Position IN Employees.Position%TYPE,
    p_Salary IN Employees.Salary%TYPE,
    p_Department IN Employees.Department%TYPE,
    p_HireDate IN Employees.HireDate%TYPE
  );

  FUNCTION CalculateAnnualSalary(
    p_EmployeeID IN Employees.EmployeeID%TYPE
  ) RETURN NUMBER;
END EmployeeManagement;

CREATE OR REPLACE PACKAGE BODY EmployeeManagement AS
  PROCEDURE HireEmployee(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_Name IN Employees.Name%TYPE,
    p_Position IN Employees.Position%TYPE,
    p_Salary IN Employees.Salary%TYPE,
    p_Department IN Employees.Department%TYPE,
    p_HireDate IN Employees.HireDate%TYPE
  ) AS
  BEGIN
    BEGIN
      INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
      VALUES (p_EmployeeID, p_Name, p_Position, p_Salary, p_Department, p_HireDate);
      COMMIT;
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('EmployeeID already exists.');
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error hiring employee: ' || SQLERRM);
    END;
  END HireEmployee;

  PROCEDURE UpdateEmployeeDetails(
    p_EmployeeID IN Employees.EmployeeID%TYPE,
    p_Name IN Employees.Name%TYPE,
    p_Position IN Employees.Position%TYPE,
    p_Salary IN Employees.Salary%TYPE,
    p_Department IN Employees.Department%TYPE,
    p_HireDate IN Employees.HireDate%TYPE
  ) AS
  BEGIN
    BEGIN
      UPDATE Employees
      SET Name = p_Name,
          Position = p_Position,
          Salary = p_Salary,
          Department = p_Department,
          HireDate = p_HireDate
      WHERE EmployeeID = p_EmployeeID;
      IF SQL%ROWCOUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('EmployeeID does not exist.');
      ELSE
        COMMIT;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error updating employee details: ' || SQLERRM);
    END;
  END UpdateEmployeeDetails;

  FUNCTION CalculateAnnualSalary(
    p_EmployeeID IN Employees.EmployeeID%TYPE
  ) RETURN NUMBER AS
    v_Salary NUMBER := 0;  -- Initialize to 0
  BEGIN
    BEGIN
      SELECT Salary
      INTO v_Salary
      FROM Employees
      WHERE EmployeeID = p_EmployeeID;
      RETURN v_Salary * 12;  -- Assuming monthly salary, so annual salary is 12 times the monthly salary
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN 0;  -- No employee found
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error calculating annual salary: ' || SQLERRM);
        RETURN 0;  -- Return 0 in case of error
    END;
  END CalculateAnnualSalary;
END EmployeeManagement;




---------------------------------------------------------------------------------------------------------------------------------



Scenario 3: Group all account-related operations into a package.

o	Question: Create a package AccountOperations with procedures for opening a new account, closing an account, and a function to get the total balance of a customer across all accounts.



CREATE OR REPLACE PACKAGE AccountOperations AS
  PROCEDURE OpenNewAccount(
    p_AccountID IN Accounts.AccountID%TYPE,
    p_CustomerID IN Accounts.CustomerID%TYPE,
    p_AccountType IN Accounts.AccountType%TYPE,
    p_Balance IN Accounts.Balance%TYPE
  );

  PROCEDURE CloseAccount(
    p_AccountID IN Accounts.AccountID%TYPE
  );

  FUNCTION GetTotalBalance(
    p_CustomerID IN Accounts.CustomerID%TYPE
  ) RETURN NUMBER;
END AccountOperations;


CREATE OR REPLACE PACKAGE BODY AccountOperations AS
  PROCEDURE OpenNewAccount(
    p_AccountID IN Accounts.AccountID%TYPE,
    p_CustomerID IN Accounts.CustomerID%TYPE,
    p_AccountType IN Accounts.AccountType%TYPE,
    p_Balance IN Accounts.Balance%TYPE
  ) AS
  BEGIN
    BEGIN
      INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
      VALUES (p_AccountID, p_CustomerID, p_AccountType, p_Balance, SYSDATE);
      COMMIT;
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('AccountID already exists.');
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error opening new account: ' || SQLERRM);
    END;
  END OpenNewAccount;

  PROCEDURE CloseAccount(
    p_AccountID IN Accounts.AccountID%TYPE
  ) AS
  BEGIN
    BEGIN
      DELETE FROM Accounts
      WHERE AccountID = p_AccountID;
      IF SQL%ROWCOUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('AccountID does not exist.');
      ELSE
        COMMIT;
      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error closing account: ' || SQLERRM);
    END;
  END CloseAccount;

  FUNCTION GetTotalBalance(
    p_CustomerID IN Accounts.CustomerID%TYPE
  ) RETURN NUMBER AS
    v_TotalBalance NUMBER := 0;  -- Initialize to 0
  BEGIN
    BEGIN
      SELECT SUM(Balance)
      INTO v_TotalBalance
      FROM Accounts
      WHERE CustomerID = p_CustomerID;
      RETURN v_TotalBalance;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN 0;  -- No accounts found
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error retrieving total balance: ' || SQLERRM);
        RETURN 0;  -- Return 0 in case of error
    END;
  END GetTotalBalance;
END AccountOperations;



























