package com.library.repository;

public class BookRepository {
    @Override
    public String toString() {
        return "BookRepository instance";
    }

}
