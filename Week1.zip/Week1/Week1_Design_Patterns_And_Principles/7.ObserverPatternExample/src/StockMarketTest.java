// Stock.java
import java.util.ArrayList;
import java.util.List;

interface Stock {
    void registerObserver(Observer observer);
    void deregisterObserver(Observer observer);
    void notifyObservers(String stockName, double price);
}


class StockMarket implements Stock {
    private List<Observer> observers;
    private String stockName;
    @SuppressWarnings("unused") // for warning
    private double price;

    public StockMarket(String stockName, double price) {
        this.observers = new ArrayList<>();
        this.stockName = stockName;
        this.price = price;
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void deregisterObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String stockName, double price) {
        for (Observer observer : observers) {
            observer.update(stockName, price);
        }
    }

    public void setPrice(double price) {
        this.price = price;
        notifyObservers(stockName, price);
    }
}

interface Observer {
    void update(String stockName, double price);}

class MobileApp implements Observer {
    @Override
    public void update(String stockName, double price) {
        System.out.println("Mobile App: Stock " + stockName + " price updated to " + price);
    }
}


class WebApp implements Observer {
    @Override
    public void update(String stockName, double price) {
        System.out.println("Web App: Stock " + stockName + " price updated to " + price);
    }
}

public class StockMarketTest {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket("Reliance Pvt Ltd.", 100.0);

        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        stockMarket.setPrice(120.0);

        stockMarket.deregisterObserver(webApp);

        stockMarket.setPrice(130.0);
    }
}