
interface PaymentProcessor {
    void processPayment(String paymentMethod, double amount);
}

class PayPalGateway {
    public void payWithPayPal(String paymentMethod, double amount) {
        System.out.println("Processing payment of Rs " + amount + " using PayPal with " + paymentMethod);
    }
}


class GooglePayGateway {
    public void payWithGooglePay(String paymentMethod, double amount) {
        System.out.println("Processing payment of Rs " + amount + " using GooglePay with " + paymentMethod);
    }
}


class BankTransferGateway {
    public void transferWithBank(String paymentMethod, double amount) {
        System.out.println("Processing payment of Rs " + amount + " using Bank Transfer with " + paymentMethod);
    }
}


class PayPalAdapter implements PaymentProcessor {
    private PayPalGateway payPalGateway;

    public PayPalAdapter(PayPalGateway payPalGateway) {
        this.payPalGateway = payPalGateway;
    }

    @Override
    public void processPayment(String paymentMethod, double amount) {
        payPalGateway.payWithPayPal(paymentMethod, amount);
    }
}


class GooglePayAdapter implements PaymentProcessor {
    private GooglePayGateway GooglePayGateway;

    public GooglePayAdapter(GooglePayGateway GooglePayGateway) {
        this.GooglePayGateway = GooglePayGateway;
    }

    @Override
    public void processPayment(String paymentMethod, double amount) {
        GooglePayGateway.payWithGooglePay(paymentMethod, amount);
    }
}


class BankTransferAdapter implements PaymentProcessor {
    private BankTransferGateway bankTransferGateway;

    public BankTransferAdapter(BankTransferGateway bankTransferGateway) {
        this.bankTransferGateway = bankTransferGateway;
    }

    @Override
    public void processPayment(String paymentMethod, double amount) {
        bankTransferGateway.transferWithBank(paymentMethod, amount);
    }
}

public class PaymentProcessorTest {
    public static void main(String[] args) {
        // Create payment gateways
        PayPalGateway payPalGateway = new PayPalGateway();
        GooglePayGateway GooglePayGateway = new GooglePayGateway();
        BankTransferGateway bankTransferGateway = new BankTransferGateway();

        // Create adapters for each payment gateway
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        PaymentProcessor GooglePayAdapter = new GooglePayAdapter(GooglePayGateway);
        PaymentProcessor bankTransferAdapter = new BankTransferAdapter(bankTransferGateway);

        // Process payments using adapters
        payPalAdapter.processPayment("Credit Card", 100.0);
        GooglePayAdapter.processPayment("Debit Card", 50.0);
        bankTransferAdapter.processPayment("Bank Account", 200.0);
    }
}