interface CustomerRepository {
    String findCustomerById(int id);
}
class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(int id) {
        return "Customer " + id;
    }
}
class CustomerService {
    private CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    public String getCustomerName(int id) {
        return repository.findCustomerById(id);
    }
}
public class DependencyInjectionTest {
    public static void main(String[] args) {
        // Create the repository
        CustomerRepository repository = new CustomerRepositoryImpl();

        // Inject the repository into the service
        CustomerService service = new CustomerService(repository);

        // Use the service
        int customerId = 123;
        String customerName = service.getCustomerName(customerId);
        System.out.println("Found customer: " + customerName);
    }
}