1.	Understand Array Representation:
o   Explain how arrays are represented in memory and their advantages.

Contiguous Memory Allocation:
Arrays are stored in contiguous blocks of memory. Each element of the array is positioned next to the previous element, making it easy to compute the address of any element if the base address and the size of each element are known.
Indexing:
Array elements can be accessed using an index. This index is typically zero-based in most programming languages (i.e., the first element is at index 0).

Advantages of Arrays:
Direct Access
Ease of Sorting and Searching
Efficient Iteration
Simplicity
Predictable Memory Usage



4.	Analysis:
o	Analyze the time complexity of each operation (add, search, traverse, delete).
Add (Append): Best Case: O(1), Worst Case: O(1)
Fast and efficient for appending elements to the end of the array, with a constant time complexity.

Add (Insert): Best Case: O(1), Worst Case: O(n)
Can be costly if insertion occurs at the beginning or middle of the array due to the need to shift elements.

Search: Best Case: O(1), Worst Case: O(n), Binary Search: O(log n)
Linear search is straightforward but can be inefficient for large arrays. 
Binary search significantly improves search time for sorted arrays.

Traverse: Best Case: O(n), Worst Case: O(n)
Traversal has a linear time complexity, making it straightforward and predictable.

Delete: Best Case: O(1), Worst Case: O(1)/O(n)
Removing elements from the end is efficient, but deleting from arbitrary positions can be costly due to the need to shift elements.



o	Discuss the limitations of arrays and when to use them.
Limitations:
1.Fixed Size: Once an array is created, its size cannot be changed.
2.Costly Insertions and Deletions: Inserting or deleting an element from an arbitrary position requires shifting elements.
3.Homogeneous Data: Arrays typically store elements of the same data type.
4.Contiguous Memory Requirement: Arrays require a contiguous block of memory.

When to Use Arrays:
1.When Random Access is Needed
2.When Size is Known and Fixed
3.For Simple Collections
4.For Performance-Critical Applications