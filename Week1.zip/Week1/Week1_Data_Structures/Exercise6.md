Exercise-6

1.	Understand Search Algorithms:
o	Explain linear search and binary search algorithms.

Understanding:

Linear Search algorithm is as follows:
1. Initialization: Start at the first element of the list.
2. Comparison: Compare the current element with the given target value.
3. Match Check: If the current element matches the target, return the index of the element.
4. Move to Next Element: If the current element does not match the target, move to the next element.
5. Continue: Repeat the comparison and move to the next element until the end of the list is reached.
6. End of List: If the end of the list is reached and the target is not found, return a value indicating that the target
is not in the list such as "-1" or "null".
7. Time Complexity: - O(n), where n is the number of elements in the list.

Binary search algorithm is as follows:
1. Initialization: Start with the entire sorted list, and define the 'low' and 'high' pointers at the beginning and end of the list, respectively.
2. Calculate Midpoint: Calculate the midpoint index with the formula: 'mid = (low + high) / 2'.
3. Comparison: Compare the element at the midpoint with the given target value.
4. Check: If the midpoint element matches the target, return the index.
5. Change Range: If the target is less than the midpoint element, update the 'high' pointer to 'mid - 1' to search in the left half.
 If the target is greater, update the 'low' pointer to 'mid + 1' to search in the right half.
6. Repeat: Repeat the process of calculating the midpoint, comparing, and adjusting the search range until the target is found or 'low' exceeds 'high'.
7. End of Search: If 'low' exceeds 'high', the target is not in the list, return a value indicating the absence of the element such as  "-1" or "null".
8. Time Complexity: O(log n), where n is the number of elements in the list.






4.	Analysis:
o	Compare the time complexity of linear and binary search.
Compairing the time Complexities of Binary Search and Linear Search as follows:
Linear Search:
-Time Complexity:O(n)
Linear search works by examining each element in the list one by one until it finds the target or reaches the end of the list.
Therefore, in the worst case it would need to check every element till the end, making it linear with respect to the number of elements.
Binary Search:
-Time Complexity:O(log n)
Binary search works by repeatedly dividing the search interval in half. If the list is sorted, binary search compares the
target value to the middle element and eliminates half of the remaining elements from consideration. This reduction
in the search space makes it much more efficient for larger lists.



o	Discuss when to use each algorithm based on the data set size and order.
Linear Search is supposed to be used in the following cases:
  - When the list is unsorted.
  - When simplicity is a priority, as linear search is easy to implement and understand.
  - When the list is small or when the overhead of sorting a large list to use binary search outweighs the benefits.
In short Linear Search is best for small or unsorted datasets due to its simplicity and ease of implementation.
It doesn’t require the dataset to be sorted.

Whereas Binary Search is supposed to be used in the following cases:
  - When the list is sorted or can be sorted, as binary search requires a sorted list to work correctly.
  - When we need to perform multiple search operations on a large dataset, as binary search would be significantly faster than linear search for large lists.
  - When the data set size is large enough that the O(log n) complexity gives a prominent performance improvement over O(n).
In short Binary Search is optimal for large, sorted datasets due to its efficient O(log n) complexity. However, it
requires the list to be sorted beforehand

