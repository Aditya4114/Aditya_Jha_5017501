Exercise-7


1.	Understand Recursive Algorithms:
o	Explain the concept of recursion and how it can simplify certain problems.

1.Recursion can be specified as a function calling itself , it is basically a programming technique wherein a function calls
itself to solve smaller instances of the same problem. It simplifies complex problems by breaking them down into more manageable sub-problems.
Each recursive call typically operates on a smaller or simpler version of the original problem until it reaches a base case,
which is a condition where the problem can be solved directly without further recursion.
The key components of recursion are:
1. Base Case: Defines the simplest instance of the problem which can be solved directly, preventing infinite recursion by providing a stopping point.
2. Recursive Case: The part of the function that reduces the problem size and makes a recursive call, moving closer to the base case.

Recursion simplifies problems by allowing elegant and concise solutions for tasks that involve repetitive or nested structures,
such as tree traversals or factorial calculations.
For example, calculating the factorial of a number or traversing a file directory can be more intuitively expressed with recursion,
reducing the need for complex iterative loops.




Step-4
Analysis:-
o	Discuss the time complexity of your recursive algorithm.
The time Complexity of Recursive Algorithms can be computed as follows:
It depends on two main factors-
1. Number of Recursive Calls: How many times the function calls itself.
2. Work Done Per Call: The amount of computation performed outside the recursive calls.
For instance, in a naive recursive approach to calculating the Fibonacci sequence, the function calls itself multiple times
for each Fibonacci number, leading to an exponential number of calls. This results in a time complexity of O(2^n), where n is the input number.


o	Explain how to optimize the recursive solution to avoid excessive computation.
The Recursive Solutions can be optimised as follows in order to avoid excessive solutions:
1. Memoization:
   - This technique involves storing the results of expensive function calls and reusing these results when the same inputs occur again. By doing so, it avoids redundant calculations.
   - In the practical way we can keep track of already computed results in a table or dictionary, and before making a recursive call, we check if the result is already available or not.
2. Dynamic Programming:
   - Instead of using recursion, dynamic programming solves the problem iteratively by building up a solution from smaller subproblems.
    It stores intermediate results in a table (array) to avoid recalculating them, which helps in reducing the overall time complexity.
   - This method typically converts a recursive solution into an iterative one, allowing you to compute results in a more efficient manner.
