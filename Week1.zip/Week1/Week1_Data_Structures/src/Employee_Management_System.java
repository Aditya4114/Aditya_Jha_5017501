// Exercise 4: Employee Management System
import java.util.*;



public class Employee_Management_System {

    public static void main(String[] args) {
        EMS ems = new EMS();

        // Adding employees
        ems.addEmployee(new Employee(1, "John Doe", "Developer", 75000));
        ems.addEmployee(new Employee(2, "Jane Smith", "Manager", 90000));
        ems.addEmployee(new Employee(3, "Bob Johnson", "Designer", 65000));

        // Traversing employees
        System.out.println("All Employees:");
        ems.traverseEmployees();

        // Searching for an employee
        Employee foundEmployee = ems.searchEmployee(2);
        System.out.println("\nFound Employee: " + foundEmployee);

        // Deleting an employee
        boolean deleted = ems.deleteEmployee(1);
        System.out.println("\nEmployee deleted: " + deleted);

        // Traversing again after deletion
        System.out.println("\nEmployees after deletion:");
        ems.traverseEmployees();
    }
}

class Employee {
    private int employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(int employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    // Getters and setters
    public int getEmployeeId() { return employeeId; }
    public String getName() { return name; }
    public String getPosition() { return position; }
    public double getSalary() { return salary; }

    @Override
    public String toString() {
        return "Employee{" + "id=" + employeeId + ", name='" + name + '\'' + ", position='" + position + '\'' + ", salary=" + salary + '}';
    }
}


class EMS{
    private Employee[] employees;
    private int size;
    private static final int INITIAL_CAPACITY = 10;

    public EMS() {
        employees = new Employee[INITIAL_CAPACITY];
        size = 0;
    }

    public void addEmployee(Employee employee) {
        if (size == employees.length) {
            employees = Arrays.copyOf(employees, employees.length * 2);
        }
        employees[size++] = employee;
    }

    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }

    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                System.arraycopy(employees, i + 1, employees, i, size - i - 1);
                employees[--size] = null;
                return true;
            }
        }
        return false;
    }
}
