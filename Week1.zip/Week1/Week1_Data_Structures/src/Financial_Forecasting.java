public class Financial_Forecasting {

    public static double calculateFutureValue(double presentValue, double growthRate, int years) {
        // Base case: if years is 0, return the present value
        if (years == 0) {
            return presentValue;
        }
        
        // Recursive case: calculate the value for the previous year and apply growth
        return calculateFutureValue(presentValue, growthRate, years - 1) * (1 + growthRate);
    }

    public static void printForecast(double initialValue, double growthRate, int years) {
        System.out.println("Year\tPredicted Value");
        for (int i = 0; i <= years; i++) {
            double futureValue = calculateFutureValue(initialValue, growthRate, i);
            System.out.printf("%d\t$%.2f%n", i, futureValue);
        }
    }

    public static void main(String[] args) {
        double initialInvestment = 10000;  // $10,000 initial investment
        double annualGrowthRate = 0.07;    // 7% annual growth rate
        int forecastYears = 10;            // Forecast for 10 years

        System.out.println("Financial Forecast:");
        System.out.printf("Initial Investment: $%.2f%n", initialInvestment);
        System.out.printf("Annual Growth Rate: %.2f%%%n", annualGrowthRate * 100);
        System.out.printf("Forecast Period: %d years%n%n", forecastYears);

        printForecast(initialInvestment, annualGrowthRate, forecastYears);
    }
}