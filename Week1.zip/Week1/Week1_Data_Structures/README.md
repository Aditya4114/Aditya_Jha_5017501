This is a compiled project with all the exercises.
All the java codes for the exercises are in the src folder with their respective .md files.
.Md files contains answers to the questions on the particular exercise.