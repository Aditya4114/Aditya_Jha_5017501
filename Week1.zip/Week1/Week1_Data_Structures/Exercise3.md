1.	Understand Sorting Algorithms:
o	Explain different sorting algorithms (Bubble Sort, Insertion Sort, Quick Sort, Merge Sort).

Bubble Sort:
Bubble Sort repeatedly steps through the list, compares adjacent elements, and swaps them if they are in the wrong order. The process is repeated until the list is sorted.

Procedure:
Compare the first two elements of the array.
If the first element is greater than the second, swap them.
Move to the next pair of elements and repeat the process until the end of the array.
Repeat the entire process for the entire array until no swaps are needed.

Time Complexity:
Best Case: O(n)
Average Case: O(n^2)
Worst Case: O(n^2)

Use Case:
Simple to understand and implement.
Not suitable for large datasets due to its poor time complexity.



Insertion Sort:
Insertion Sort builds the final sorted array one item at a time. It picks the next element and inserts it into the correct position in the already sorted part of the array.

Procedure:
Start with the second element (assume the first element is already sorted).
Compare the current element with the sorted elements to its left.
Shift all the larger elements to the right to create the correct position for the current element.
Insert the current element into its correct position.
Repeat until all elements are sorted.

Time Complexity:
Best Case: O(n)
Average Case: 0(n^2)
Worst Case: 0(n^2)

Use Case:
Efficient for small datasets or nearly sorted arrays.
Simple and efficient for small datasets, but not suitable for large datasets.



Quick Sort:
Quick Sort is a divide-and-conquer algorithm. It works by selecting a 'pivot' element and partitioning the array into two sub-arrays: one with elements less than the pivot and one with elements greater than the pivot. It then recursively sorts the sub-arrays.

Procedure:
Choose a pivot element from the array.
Partition the array into two parts: elements less than the pivot and elements greater than the pivot.
Recursively apply the above steps to the sub-arrays.
Combine the sorted sub-arrays to produce the final sorted array.

Time Complexity:
Best Case: O(n log n)
Average Case: 0(n log n)
Worst Case: 0(n^2)

Use Case:
Efficient and widely used for large datasets.
Performance can be improved by using random pivoting or the median-of-three method to choose the pivot.



Merge Sort:
Merge Sort is another divide-and-conquer algorithm. It works by dividing the array into two halves, sorting each half, and then merging the sorted halves to produce the final sorted array.

Procedure:
Divide the array into two halves.
Recursively sort each half.
Merge the two sorted halves to produce the final sorted array.

Time Complexity:
Best Case: O(n log n)
Average Case: 0(n log n)
Worst Case: 0(n log n)

Use Case: 
Efficient and stable sorting algorithm.
Preferred for large datasets and linked lists.
Uses additional memory for the temporary arrays during merging.



4.	Analysis:
o	Compare the performance (time complexity) of Bubble Sort and Quick Sort.
Bubble sort: 
Time complexity:
Best Case: O(n)
Occurs when the array is already sorted. A single pass is needed to confirm the array is sorted.
Average Case: O(n^2)
Typical case for random arrays.
Worst Case: O(n^2)
Occurs when the array is sorted in reverse order.


Quick Sort:
Time complexity:
Best Case: O(n log n)
Occurs when the pivot selection consistently divides the array into two nearly equal halves.
Average Case: 0(n log n)
Typical case for random arrays, as the division is on average close to even.
Worst Case: O(n^2)
Occurs when the pivot selection consistently picks the smallest or largest element as the pivot, leading to highly unbalanced partitions.



o	Discuss why Quick Sort is generally preferred over Bubble Sort.
1.Quick Sort's average time complexity is significantly better than Bubble Sort's. For large datasets, the difference between O(n log n) and O(n^2) becomes substantial, making Quick Sort much faster and more efficient.
2.Quick Sort is widely implemented in standard libraries and frameworks due to its efficiency and reliability. It is a general-purpose sorting algorithm that performs well across various types of data and real-world applications.
3.Quick Sort is generally preferred over Bubble Sort due to its superior average-case time complexity, scalability, and practical efficiency. While Bubble Sort is simple and may have some niche uses, Quick Sort's performance and adaptability make it the algorithm of choice for most sorting tasks in real-world applications.

