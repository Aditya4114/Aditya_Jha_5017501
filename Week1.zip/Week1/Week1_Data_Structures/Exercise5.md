Exercise-5

1.	Understand Linked Lists:
o	Explain the different types of linked lists (Singly Linked List, Doubly Linked List).


Understanding:-

The different types of linkedLists(singly linkedlist and doubly linkedlist) are:
Singly Linked List:
- Consists of nodes, having data in it and a pointer, pointing to the next node.
- It follows one-directional traversal from head(first node) to tail(last node).
- Time complexity of Insertion/Deletion: O(1) at beginning, O(n) at middle and end.
- It is memory-efficient due to a single pointer per node.
- They are mainly used for Simple lists, stacks, queues.
Doubly Linked List:
- It consists of nodes containing data, a pointer to the next node, and a pointer to the previous node as well.
- It follows bidirectional traversal from head to tail as well as tail to head.
- Time complexity of Insertion/Deletion: O(1) at beginning and end, O(n) at middle.
- Requires more memory per node due to presence of two pointers.
- They are mainly used for bidirectional navigation, undo/redo systems.



4. Analysis:-
o	Analyze the time complexity of each operation.
Time Complexity Analysis of Linked List Operations are as follows:
1. Add:
   - At the Beginning: O(1) for both singly and doubly linked lists.
   - At the End: O(n) if the list does not maintain a tail pointer and O(1) if it does maintain a tail pointer.
   - At the Middle: O(n) due to traversal to find the insertion point.
2. Search:
   - O(n) for both singly and doubly linked lists, as we need to traverse to find the target element.
3. Traverse:
   - O(n) for both singly and doubly linked lists, as each node needs to be accessed sequentially.
4. Delete:
   - At the Beginning: O(1) for both singly and doubly linked lists.
   - At the End: O(n) if the list does not maintain a tail pointer and O(1) if it does maintain a tail pointer.
   - At the Middle: O(n) due to traversal to find the node to delete. In doubly linked lists, O(1) if the node is known.


o	Discuss the advantages of linked lists over arrays for dynamic data.
The advantages of Linked Lists Over Arrays for Dynamic Data are as follows:
1.Dynamic Size: Linked lists can be extended or reduced in size dynamically without needing to allocate a new block of memory, unlike arrays, which require a fixed size or expensive resizing operations.
2.Efficient Insertions and Deletions:Arrays require shifting elements (O(n)) when inserting in middle but in linkedlists the insertions and deletions, especially at the beginning or middle of the list, are more efficient with O(1) time complexity when the element is known.
3.Memory Utilization: Unlike arrays, Linked lists allocate memory as needed, which can be more efficient for applications with unpredictable or dynamic data sizes.
4.Ease of Implementation for Complex Structures: Linked lists can easily represent complex structures such as stacks, queues, and graphs.
